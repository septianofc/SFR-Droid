# SFR Droid — Wizard build project

Capacitor 8.5.3 Android project. UI is a full-screen step-by-step wizard and the app selector queries installed Android applications via native PackageManager.

## Build on SwapLab
- Framework: Capacitor
- Engine: 8.5.3
- Upload this ZIP
- Android compile/target SDK: 36 (if the builder allows; min SDK 24)
- Build Debug APK

## Important
This source ZIP is not an APK. It has not been built or device-tested in this environment. Test notification access, the installed-app list, HTTP responses, background heartbeat, and battery behavior on the target device before relying on it. Android will not allow an app to grant notification access silently; the user must enable it in system settings.
