package id.sfrdroid.app;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;
public class HeartbeatWorker extends Worker {
 public HeartbeatWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
 @NonNull @Override public Result doWork(){
  try{
   if(!getApplicationContext().getSharedPreferences("sfr_config",Context.MODE_PRIVATE).getBoolean("standby",false))return Result.success();
   JSONObject p=new JSONObject();p.put("event","heartbeat");p.put("app","SFR Droid");p.put("timestamp",System.currentTimeMillis());
   ApiSender.send(getApplicationContext(),p);
   return Result.success();
  }catch(Exception e){return Result.retry();}
 }
}
