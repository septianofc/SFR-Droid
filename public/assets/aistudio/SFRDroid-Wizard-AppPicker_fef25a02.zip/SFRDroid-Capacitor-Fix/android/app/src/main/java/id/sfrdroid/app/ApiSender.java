package id.sfrdroid.app;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiSender {
 private static final ExecutorService EXEC=Executors.newSingleThreadExecutor();
 public static void send(Context context, JSONObject payload){
  Context app=context.getApplicationContext();
  EXEC.execute(()->{
   HttpURLConnection c=null;
   try{
    SharedPreferences p=app.getSharedPreferences("sfr_config",Context.MODE_PRIVATE);
    String endpoint=p.getString("endpoint",""); if(endpoint==null||endpoint.trim().isEmpty())return;
    URL url=new URL(endpoint); c=(HttpURLConnection)url.openConnection();
    c.setRequestMethod("POST"); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setDoOutput(true);
    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
    String token=p.getString("token",""); if(token!=null&&!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
    byte[] body=payload.toString().getBytes(StandardCharsets.UTF_8);
    c.setFixedLengthStreamingMode(body.length);
    try(OutputStream os=c.getOutputStream()){os.write(body);}
    int code=c.getResponseCode();
   }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
  });
 }
}
