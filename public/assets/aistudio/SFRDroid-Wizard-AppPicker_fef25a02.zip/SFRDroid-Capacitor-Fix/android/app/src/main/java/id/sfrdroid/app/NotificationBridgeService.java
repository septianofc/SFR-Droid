package id.sfrdroid.app;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import org.json.JSONObject;
import org.json.JSONArray;

public class NotificationBridgeService extends NotificationListenerService {
 @Override public void onNotificationPosted(StatusBarNotification sbn){
   try {
     SharedPreferences p=getSharedPreferences("sfr_config",MODE_PRIVATE);
     if(!p.getBoolean("standby",false)) return;
     String pkg=sbn.getPackageName();
     JSONArray apps=new JSONArray(p.getString("apps","[]"));
     boolean allow=false;
     for(int i=0;i<apps.length();i++) if(pkg.equals(apps.optString(i))){allow=true;break;}
     if(!allow) return;
     Notification n=sbn.getNotification(); if(n==null||n.extras==null)return;
     String title=String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TITLE,""));
     String message=String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TEXT,""));
     String app=pkg;
     try { app=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)).toString(); }catch(Exception ignored){}
     JSONArray fields=new JSONArray(p.getString("fields","[\"title\",\"message\",\"timestamp\"]"));
     JSONObject out=new JSONObject();
     for(int i=0;i<fields.length();i++){
       String f=fields.optString(i);
       if(f.equals("app"))out.put("app",app);
       else if(f.equals("package"))out.put("package",pkg);
       else if(f.equals("title"))out.put("title",title);
       else if(f.equals("message"))out.put("message",message);
       else if(f.equals("timestamp"))out.put("timestamp",sbn.getPostTime());
       else if(f.equals("key"))out.put("key",sbn.getKey());
     }
     out.put("event","notification");
     ApiSender.send(this,out);
   }catch(Exception ignored){}
 }
}
