package id.sfrdroid.app;

import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.TimeUnit;

@CapacitorPlugin(name = "SFRBridge")
public class SFRBridgePlugin extends Plugin {
  private SharedPreferences prefs(){ return getContext().getSharedPreferences("sfr_config", Context.MODE_PRIVATE); }
  @PluginMethod public void getStatus(PluginCall call){
    Context ctx=getContext(); SharedPreferences p=prefs();
    JSObject o=new JSObject();
    String enabled=Settings.Secure.getString(ctx.getContentResolver(),"enabled_notification_listeners");
    boolean access=enabled!=null && enabled.contains(ctx.getPackageName()+"/"+NotificationBridgeService.class.getName());
    boolean ignoring=true;
    if(Build.VERSION.SDK_INT>=23){ PowerManager pm=(PowerManager)ctx.getSystemService(Context.POWER_SERVICE); ignoring=pm!=null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName()); }
    o.put("notificationAccess",access); o.put("ignoringBatteryOptimizations",ignoring);
    o.put("standby",p.getBoolean("standby",false));
    String endpoint=p.getString("endpoint",""); o.put("endpointConfigured",endpoint!=null&&!endpoint.trim().isEmpty());
    call.resolve(o);
  }

  @PluginMethod public void getInstalledApps(PluginCall call){
    JSONArray out=new JSONArray();
    try {
      android.content.pm.PackageManager pm=getContext().getPackageManager();
      java.util.List<android.content.pm.ApplicationInfo> list=pm.getInstalledApplications(0);
      java.util.Collections.sort(list,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
      for(android.content.pm.ApplicationInfo ai:list){
        if(ai.packageName.equals(getContext().getPackageName())) continue;
        JSONObject item=new JSONObject(); item.put("package",ai.packageName); item.put("name",String.valueOf(pm.getApplicationLabel(ai)));
        item.put("system",(ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM)!=0); out.put(item);
      }
    } catch(Exception ignored) {}
    JSObject result=new JSObject(); result.put("apps",out); call.resolve(result);
  }
  @PluginMethod public void openAppDetails(PluginCall call){
    try { Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getContext().getPackageName())); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); call.resolve(); } catch(Exception e){call.reject("Pengaturan aplikasi tidak dapat dibuka.",e);}
  }
  @PluginMethod public void getConfig(PluginCall call) {
    JSObject o=new JSObject(); SharedPreferences p=prefs();
    o.put("endpoint",p.getString("endpoint","")); o.put("token",p.getString("token",""));
    o.put("standby",p.getBoolean("standby",false)); o.put("interval",p.getInt("interval",15));
    try { o.put("apps",new JSArray(p.getString("apps","[]"))); o.put("fields",new JSArray(p.getString("fields","[\"title\",\"message\",\"timestamp\"]"))); } catch (Exception e) { o.put("apps",new JSArray()); o.put("fields",new JSArray()); }
    call.resolve(o);
  }
  @PluginMethod public void saveConfig(PluginCall call){
    String endpoint=call.getString("endpoint","").trim(); String token=call.getString("token","");
    boolean standby=call.getBoolean("standby",false);
    prefs().edit().putString("endpoint",endpoint).putString("token",token).putBoolean("standby",standby).apply();
    scheduleHeartbeat(standby); call.resolve();
  }
  @PluginMethod public void saveApps(PluginCall call){
    JSArray a=call.getArray("apps"); if(a==null)a=new JSArray(); prefs().edit().putString("apps",a.toString()).apply(); call.resolve();
  }
  @PluginMethod public void saveFields(PluginCall call){
    JSArray a=call.getArray("fields"); if(a==null)a=new JSArray(); prefs().edit().putString("fields",a.toString()).apply(); call.resolve();
  }
  @PluginMethod public void saveInterval(PluginCall call){
    int n=Math.max(15,Math.min(1440,call.getInt("interval",15))); prefs().edit().putInt("interval",n).apply();
    scheduleHeartbeat(prefs().getBoolean("standby",false)); call.resolve();
  }
  @PluginMethod public void setStandby(PluginCall call){
    boolean enabled=call.getBoolean("enabled",false); prefs().edit().putBoolean("standby",enabled).apply();
    scheduleHeartbeat(enabled); call.resolve();
  }
  @PluginMethod public void openNotificationSettings(PluginCall call){
    try { Intent i=new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); call.resolve(); }
    catch(Exception e){call.reject(e.getMessage());}
  }
  @PluginMethod public void openBatterySettings(PluginCall call){
    Context ctx=getContext();
    try {
      Intent i;
      if(Build.VERSION.SDK_INT>=23){
        i=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:"+ctx.getPackageName()));
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); call.resolve(); return; }
        catch(Exception ignored) { i=new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS); }
      } else { i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+ctx.getPackageName())); }
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); call.resolve();
    } catch(Exception e){
      try { Intent fallback=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+ctx.getPackageName())); fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(fallback); call.resolve(); }
      catch(Exception e2){call.reject("Pengaturan baterai tidak dapat dibuka pada perangkat ini.");}
    }
  }
  @PluginMethod public void sendTest(PluginCall call){
    JSONObject payload=new JSONObject(); try {payload.put("event","test");payload.put("app","SFR Droid");payload.put("timestamp",System.currentTimeMillis());}catch(Exception ignored){}
    ApiSender.send(getContext(),payload); call.resolve();
  }
  private void scheduleHeartbeat(boolean enabled){
    WorkManager wm=WorkManager.getInstance(getContext());
    if(!enabled){wm.cancelUniqueWork("sfr-heartbeat");return;}
    int interval=Math.max(15,prefs().getInt("interval",15));
    Constraints c=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(HeartbeatWorker.class,interval,TimeUnit.MINUTES).setConstraints(c).build();
    wm.enqueueUniquePeriodicWork("sfr-heartbeat", ExistingPeriodicWorkPolicy.UPDATE,req);
  }
}
